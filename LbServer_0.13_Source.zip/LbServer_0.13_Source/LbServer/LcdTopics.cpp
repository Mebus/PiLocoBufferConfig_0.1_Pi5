// $Id: LcdTopics.cpp 1254 2023-02-22 13:48:11Z pischky $

#include "LcdTopics.h"

// static instances
CSyncMutex CTopic::LcdMutex;
