// $Id: Version.h 1291 2023-03-29 14:07:03Z pischky $
#ifndef _VERSION_H_
#define _VERSION_H_


#define VERSION "0.13"
#define PROTOCOL "1"


#endif
