// $Id: Version.h 1326 2023-05-07 09:35:07Z pischky $
#ifndef _VERSION_H_
#define _VERSION_H_


#define VERSION "0.14"
#define PROTOCOL "1"


#endif
