// $Id: resource.h 1171 2023-01-07 12:56:40Z sbormann71 $
// Microsoft Developer Studio generated include file.
// handedit by Stefan Borman and Martin Pischky
// Used by Recourses.rc
//
#define IDI_ICON                        101
#define VS_VERSION_INFO					1
