//////////////////////////////////////////////////////////////////////////////
// File name:		SerialPort.h
// $Id: SerialPort.h 1226 2023-02-14 11:02:08Z pischky $
//
// Class/Module(s):	CSerialPort
//
// Description:		Communication with the serial port
//
// Author(s):		If this code works: UW
//
// History			15.07.1999	Version 0.1
//					28.07.1999	IsOpened() function added
//					2000-05-03
//                  2006-11-22 Modified for linux, Ian Cunningham
//
//////////////////////////////////////////////////////////////////////////////


#ifndef _SERIAL_PORT_H_
#define _SERIAL_PORT_H_


const int SERIAL_PORT_STRING_LENGTH=128;


class CSerialPort  
{
public:
	enum EDataBits
	{
		DATA_BITS_5_E = 5,
		DATA_BITS_6_E = 6,
		DATA_BITS_7_E = 7,
		DATA_BITS_8_E = 8
	} m_enDataBits;

	enum EStopBits
	{
		STOP_BITS_1_E = 0,
		STOP_BITS_1P5_E = 1,
		STOP_BITS_2_E = 2
	} m_enStopBits;
	
	enum EParity
	{
		NO_PARITY_E = 0,
		ODD_PARITY_E = 1,
		EVEN_PARITY_E = 2,
		MARK_PARITY_E = 3,
		SPACE_PARITY_E = 4
	} m_enParity;

	enum EFlow
	{
		FLOW_CONTROL_NONE_E = 0,
		FLOW_CONTROL_CTS_E = 1
	} m_enFlow;

	char m_acPort[SERIAL_PORT_STRING_LENGTH];

	CSerialPort(unsigned int uiTxBufferSize = 1024, unsigned int uiRxBufferSize = 1024);
	virtual ~CSerialPort();
	bool Open(const char *pcPort, int iBaud = 9600, EDataBits DataBits = DATA_BITS_8_E, EStopBits StopBits = STOP_BITS_1_E, EParity Parity = NO_PARITY_E, EFlow Flow = FLOW_CONTROL_NONE_E);
	bool Close(void);
	bool Read(void *pvBuffer, unsigned int uiNumOfBytes, unsigned long *pulNumOfBytesRead);
	bool ReadBlocking(void *pvBuffer, unsigned int uiNumOfBytes, unsigned long *pulNumOfBytesRead);
	bool Write(void *pvBuffer, unsigned int uiNumOfBytes);
	bool Reset(void);
	bool GetOpenStatus(void) { if(m_hComm < 0) return false; else return true; }

protected:

	int m_hComm; // return value of open():
	             //   m_hComm >= 0 : file descriptor
	             //   m_hComm == -1: error, no file open
	int m_iBaud;
	unsigned int m_uiTxBufferSize;
	unsigned int m_uiRxBufferSize;
};


#endif
